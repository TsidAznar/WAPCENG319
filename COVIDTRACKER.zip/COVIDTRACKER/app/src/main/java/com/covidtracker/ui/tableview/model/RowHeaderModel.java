package com.covidtracker.ui.tableview.model;


public class RowHeaderModel {
    private String mData;

    public RowHeaderModel(String mData) {
        this.mData = mData;
    }

    public String getData() {
        return mData;
    }
}
