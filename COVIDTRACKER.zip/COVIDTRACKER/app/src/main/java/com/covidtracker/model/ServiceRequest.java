package com.covidtracker.model;

public class ServiceRequest {

    public ServiceRequest() {

    }


}
