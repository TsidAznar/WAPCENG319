package com.covidtracker.model;

public class CountryData {

    public int cases;
    public int active;


}
