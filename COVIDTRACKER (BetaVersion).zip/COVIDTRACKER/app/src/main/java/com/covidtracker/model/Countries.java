package com.covidtracker.model;
import java.util.List;

public class Countries {

    public String Country;
    public String flag;
    public List<CountryData> CountryData;


}
